function mostrarSenha(){
    var inputSenha = document.getElementById("senha")
    var olhoAbrido = document.getElementById('olho')

    if(inputSenha.type === 'password'){
        inputSenha.setAttribute('type','text')
        olhoAbrido.classList.replace('bi-eye','bi-eye-slash')
    }else{
        inputSenha.setAttribute('type','password')
        olhoAbrido.classList.replace('bi-eye-slash','bi-eye')
    }
}
function validateForm() {
    var username = document.getElementById("username").value;
    var senha = document.getElementById("senha").value;

    if (username === "" || senha === "") {
        alert("Preenche tudo ai preguiçoso!!");
    } else {
        window.location.href = 'PagInicial/Pag.html';
    }
}

function mostrarSenha() {
    var senha = document.getElementById("senha");
    if (senha.type === "password") {
        senha.type = "text";
    } else {
        senha.type = "password";
    }
}
