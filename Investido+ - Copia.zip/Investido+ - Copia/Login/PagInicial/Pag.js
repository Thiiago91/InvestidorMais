document.getElementById('form-adicionar').addEventListener('submit', function(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value;
    const quantidade = parseInt(document.getElementById('quantidade').value);
    const valorAtual = parseFloat(document.getElementById('valor-atual').value);
    const valorTotal = quantidade * valorAtual;

    adicionarAcao(nome, quantidade, valorAtual, valorTotal);
    this.reset();
});

function adicionarAcao(nome, quantidade, valorAtual, valorTotal) {
    const tabela = document.getElementById('tabela-acoes').getElementsByTagName('tbody')[0];
    const novaLinha = tabela.insertRow();

    novaLinha.insertCell(0).innerText = nome;
    novaLinha.insertCell(1).innerText = quantidade;
    novaLinha.insertCell(2).innerText = valorAtual.toFixed(2);
    novaLinha.insertCell(3).innerText = valorTotal.toFixed(2);

    const acoesCell = novaLinha.insertCell(4);
    const excluirButton = document.createElement('button');
    excluirButton.innerText = 'Excluir';
    excluirButton.addEventListener('click', function() {
        tabela.deleteRow(novaLinha.rowIndex - 1);
    });
    acoesCell.appendChild(excluirButton);
}
